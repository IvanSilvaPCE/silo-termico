
export { modeloSvgService } from './modeloSvgService'
export { configuracaoService } from './configuracaoService'

// Adicione outros serviços aqui conforme necessárioio
